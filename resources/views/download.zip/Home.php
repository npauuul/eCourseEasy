<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Home - Cursos Online</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php require('Views/Partials/h.php'); ?>


    <div class="container py-5">
        <h2 class="text-center mb-4">Nuestros Cursos</h2>

        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 justify-content-center">

            <!-- Curso 1 -->
            <div class="col">
                <div class="card h-100">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Curso 1">
                    <div class="card-body">
                        <h5 class="card-title">Curso de HTML y CSS</h5>
                        <p class="card-text">Aprende desde cero a crear páginas web modernas con HTML5 y CSS3.</p>
                        <a href="#" class="btn btn-primary">Inscribirse</a>
                    </div>
                </div>
            </div>

            <!-- Curso 2 -->
            <div class="col">
                <div class="card h-100">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Curso 2">
                    <div class="card-body">
                        <h5 class="card-title">JavaScript Básico</h5>
                        <p class="card-text">Domina los fundamentos de JavaScript para programación web dinámica.</p>
                        <a href="#" class="btn btn-primary">Inscribirse</a>
                    </div>
                </div>
            </div>

            <!-- Curso 3 -->
            <div class="col">
                <div class="card h-100">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Curso 3">
                    <div class="card-body">
                        <h5 class="card-title">Python para Principiantes</h5>
                        <p class="card-text">Conoce uno de los lenguajes más populares y aprende a programar desde cero.</p>
                        <a href="#" class="btn btn-primary">Inscribirse</a>
                    </div>
                </div>
            </div>

            <!-- Curso 4 -->
            <div class="col">
                <div class="card h-100">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Curso 4">
                    <div class="card-body">
                        <h5 class="card-title">Desarrollo con React</h5>
                        <p class="card-text">Crea aplicaciones modernas de una sola página con React JS.</p>
                        <a href="#" class="btn btn-primary">Inscribirse</a>
                    </div>
                </div>
            </div>

            <!-- Curso 5 -->
            <div class="col">
                <div class="card h-100">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Curso 5">
                    <div class="card-body">
                        <h5 class="card-title">Introducción a Bases de Datos</h5>
                        <p class="card-text">Aprende a estructurar, consultar y administrar bases de datos con SQL.</p>
                        <a href="#" class="btn btn-primary">Inscribirse</a>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card h-100">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Curso 5">
                    <div class="card-body">
                        <h5 class="card-title">Introducción a Bases de Datos</h5>
                        <p class="card-text">Aprende a estructurar, consultar y administrar bases de datos con SQL.</p>
                        <a href="#" class="btn btn-primary">Inscribirse</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <?php require('Views/Partials/f.php'); ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
